import { NextResponse } from 'next/server';
import nodemailer from 'nodemailer';

// Configure SMTP transport using Hostinger credentials
const transporter = nodemailer.createTransport({
  host: 'smtp.hostinger.com',
  port: 465,
  secure: true,
  auth: {
    user: 'leads@netbots.io',
    pass: 'Leads@110',
  },
});

const rateLimit = new Map<string, { count: number; timestamp: number }>();
const RATE_LIMIT_WINDOW = 60 * 1000; // 1 minute
const MAX_REQUESTS = 5;

export async function POST(req: Request) {
  try {
    const ip = req.headers.get('x-forwarded-for') || 'anonymous';
    const now = Date.now();
    const requestData = rateLimit.get(ip);
    
    if (requestData && now - requestData.timestamp < RATE_LIMIT_WINDOW) {
      if (requestData.count >= MAX_REQUESTS) {
        return NextResponse.json({ error: 'Too many requests. Please try again later.' }, { status: 429 });
      }
      requestData.count++;
    } else {
      rateLimit.set(ip, { count: 1, timestamp: now });
    }

    const body = await req.json();

    // Honeypot validation
    if (body.website_url_honeypot || body.honeypot || body._honey) {
      return NextResponse.json({ success: true, message: 'Processed successfully.' }, { status: 200 });
    }

    const { type, name, email } = body;
    if (!type || !name || !email) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    let emailSubject = '';
    let emailHtml = '';

    if (type === 'contact') {
      emailSubject = `[Contact] New Strategy Call Inquiry: ${name}`;
      emailHtml = `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: 'Segoe UI', Arial, sans-serif; background-color: #f4f6f8; margin: 0; padding: 20px; color: #1e293b; }
            .card { background: #ffffff; border-radius: 12px; padding: 32px; max-width: 600px; margin: 0 auto; box-shadow: 0 4px 12px rgba(0,0,0,0.05); border-top: 5px solid #0052ff; }
            .header { font-size: 18px; font-weight: 800; color: #0052ff; margin-bottom: 24px; text-transform: uppercase; letter-spacing: 0.05em; }
            .item { margin-bottom: 16px; border-bottom: 1px solid #f1f5f9; padding-bottom: 12px; }
            .label { font-size: 11px; text-transform: uppercase; font-weight: 700; color: #64748b; margin-bottom: 4px; letter-spacing: 0.05em; }
            .value { font-size: 15px; color: #0f172a; line-height: 1.5; font-weight: 500; }
            .footer { margin-top: 32px; font-size: 12px; color: #94a3b8; text-align: center; border-top: 1px dashed #e2e8f0; padding-top: 16px; }
          </style>
        </head>
        <body>
          <div class="card">
            <div class="header">New Contact Inquiry</div>
            <div class="item">
              <div class="label">Full Name</div>
              <div class="value">${name}</div>
            </div>
            <div class="item">
              <div class="label">Work Email</div>
              <div class="value">${email}</div>
            </div>
            <div class="item">
              <div class="label">Company / Organization</div>
              <div class="value">${body.company || 'Not Specified'}</div>
            </div>
            <div class="item">
              <div class="label">Primary Objective</div>
              <div class="value">${body.objective || 'Not Specified'}</div>
            </div>
            <div class="item" style="border: none;">
              <div class="label">Challenge Context</div>
              <div class="value">${body.challenge || 'Not Specified'}</div>
            </div>
            <div class="footer">
              Sent automatically from NetBots Platform Core API
            </div>
          </div>
        </body>
        </html>
      `;
    } else if (type === 'training') {
      emailSubject = `[Admission] New Academy Application: ${name}`;
      emailHtml = `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: 'Segoe UI', Arial, sans-serif; background-color: #f4f6f8; margin: 0; padding: 20px; color: #1e293b; }
            .card { background: #ffffff; border-radius: 12px; padding: 32px; max-width: 600px; margin: 0 auto; box-shadow: 0 4px 12px rgba(0,0,0,0.05); border-top: 5px solid #0052ff; }
            .header { font-size: 18px; font-weight: 800; color: #0052ff; margin-bottom: 24px; text-transform: uppercase; letter-spacing: 0.05em; }
            .item { margin-bottom: 16px; border-bottom: 1px solid #f1f5f9; padding-bottom: 12px; }
            .label { font-size: 11px; text-transform: uppercase; font-weight: 700; color: #64748b; margin-bottom: 4px; letter-spacing: 0.05em; }
            .value { font-size: 15px; color: #0f172a; line-height: 1.5; font-weight: 500; }
            .footer { margin-top: 32px; font-size: 12px; color: #94a3b8; text-align: center; border-top: 1px dashed #e2e8f0; padding-top: 16px; }
          </style>
        </head>
        <body>
          <div class="card">
            <div class="header">New Course / Mentorship Admission</div>
            <div class="item">
              <div class="label">Student Name</div>
              <div class="value">${name}</div>
            </div>
            <div class="item">
              <div class="label">Email Address</div>
              <div class="value">${email}</div>
            </div>
            <div class="item">
              <div class="label">Selected Program</div>
              <div class="value">${body.program || 'Not Specified'}</div>
            </div>
            <div class="item" style="border: none;">
              <div class="label">Background & Learning Goals</div>
              <div class="value">${body.background || 'Not Specified'}</div>
            </div>
            <div class="footer">
              Sent automatically from NetBots Academy API
            </div>
          </div>
        </body>
        </html>
      `;
    } else if (type === 'demo') {
      emailSubject = `[Demo] New Platform Walkthrough Request: ${name}`;
      emailHtml = `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: 'Segoe UI', Arial, sans-serif; background-color: #f4f6f8; margin: 0; padding: 20px; color: #1e293b; }
            .card { background: #ffffff; border-radius: 12px; padding: 32px; max-width: 600px; margin: 0 auto; box-shadow: 0 4px 12px rgba(0,0,0,0.05); border-top: 5px solid #0052ff; }
            .header { font-size: 18px; font-weight: 800; color: #0052ff; margin-bottom: 24px; text-transform: uppercase; letter-spacing: 0.05em; }
            .item { margin-bottom: 16px; border-bottom: 1px solid #f1f5f9; padding-bottom: 12px; }
            .label { font-size: 11px; text-transform: uppercase; font-weight: 700; color: #64748b; margin-bottom: 4px; letter-spacing: 0.05em; }
            .value { font-size: 15px; color: #0f172a; line-height: 1.5; font-weight: 500; }
            .footer { margin-top: 32px; font-size: 12px; color: #94a3b8; text-align: center; border-top: 1px dashed #e2e8f0; padding-top: 16px; }
          </style>
        </head>
        <body>
          <div class="card">
            <div class="header">Product Demo Request</div>
            <div class="item">
              <div class="label">Contact Name</div>
              <div class="value">${name}</div>
            </div>
            <div class="item">
              <div class="label">Work Email</div>
              <div class="value">${email}</div>
            </div>
            <div class="item">
              <div class="label">Phone / WhatsApp</div>
              <div class="value">${body.phone || 'Not Specified'}</div>
            </div>
            <div class="item">
              <div class="label">Company Name</div>
              <div class="value">${body.company || 'Not Specified'}</div>
            </div>
            <div class="item">
              <div class="label">Requested SaaS Platform</div>
              <div class="value">${body.product || 'Not Specified'}</div>
            </div>
            <div class="item">
              <div class="label">Scale of Deployment</div>
              <div class="value">${body.usersCount || 'Not Specified'}</div>
            </div>
            <div class="item" style="border: none;">
              <div class="label">Custom Requirements</div>
              <div class="value">${body.requirements || 'Not Specified'}</div>
            </div>
            <div class="footer">
              Sent automatically from NetBots SaaS Pipeline API
            </div>
          </div>
        </body>
        </html>
      `;
    } else if (type === 'audit') {
      emailSubject = `[Audit] New Architecture Review Request: ${name}`;
      emailHtml = `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: 'Segoe UI', Arial, sans-serif; background-color: #f4f6f8; margin: 0; padding: 20px; color: #1e293b; }
            .card { background: #ffffff; border-radius: 12px; padding: 32px; max-width: 600px; margin: 0 auto; box-shadow: 0 4px 12px rgba(0,0,0,0.05); border-top: 5px solid #0052ff; }
            .header { font-size: 18px; font-weight: 800; color: #0052ff; margin-bottom: 24px; text-transform: uppercase; letter-spacing: 0.05em; }
            .item { margin-bottom: 16px; border-bottom: 1px solid #f1f5f9; padding-bottom: 12px; }
            .label { font-size: 11px; text-transform: uppercase; font-weight: 700; color: #64748b; margin-bottom: 4px; letter-spacing: 0.05em; }
            .value { font-size: 15px; color: #0f172a; line-height: 1.5; font-weight: 500; }
            .footer { margin-top: 32px; font-size: 12px; color: #94a3b8; text-align: center; border-top: 1px dashed #e2e8f0; padding-top: 16px; }
          </style>
        </head>
        <body>
          <div class="card">
            <div class="header">Technical Architecture Audit Request</div>
            <div class="item">
              <div class="label">Full Name</div>
              <div class="value">${name}</div>
            </div>
            <div class="item">
              <div class="label">Work Email</div>
              <div class="value">${email}</div>
            </div>
            <div class="item">
              <div class="label">Phone / WhatsApp</div>
              <div class="value">${body.phone || 'Not Specified'}</div>
            </div>
            <div class="item">
              <div class="label">Company / Organization</div>
              <div class="value">${body.company || 'Not Specified'}</div>
            </div>
            <div class="item">
              <div class="label">Primary Focus</div>
              <div class="value">${body.projectFocus || 'Not Specified'}</div>
            </div>
            <div class="item">
              <div class="label">Budget Range</div>
              <div class="value">${body.budget || 'Not Specified'}</div>
            </div>
            <div class="item">
              <div class="label">Desired Timeline</div>
              <div class="value">${body.timeline || 'Not Specified'}</div>
            </div>
            <div class="item" style="border: none;">
              <div class="label">Context / Challenges</div>
              <div class="value">${body.context || 'Not Specified'}</div>
            </div>
            <div class="footer">
              Sent automatically from NetBots Audit Capture API
            </div>
          </div>
        </body>
        </html>
      `;
    } else if (type === 'career') {
      emailSubject = `[Careers] New Job Application: ${body.roleTitle} - ${name}`;
      emailHtml = `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: 'Segoe UI', Arial, sans-serif; background-color: #f4f6f8; margin: 0; padding: 20px; color: #1e293b; }
            .card { background: #ffffff; border-radius: 12px; padding: 32px; max-width: 600px; margin: 0 auto; box-shadow: 0 4px 12px rgba(0,0,0,0.05); border-top: 5px solid #0052ff; }
            .header { font-size: 18px; font-weight: 800; color: #0052ff; margin-bottom: 24px; text-transform: uppercase; letter-spacing: 0.05em; }
            .item { margin-bottom: 16px; border-bottom: 1px solid #f1f5f9; padding-bottom: 12px; }
            .label { font-size: 11px; text-transform: uppercase; font-weight: 700; color: #64748b; margin-bottom: 4px; letter-spacing: 0.05em; }
            .value { font-size: 15px; color: #0f172a; line-height: 1.5; font-weight: 500; }
            .footer { margin-top: 32px; font-size: 12px; color: #94a3b8; text-align: center; border-top: 1px dashed #e2e8f0; padding-top: 16px; }
          </style>
        </head>
        <body>
          <div class="card">
            <div class="header">New Job Application Received</div>
            <div class="item">
              <div class="label">Applied Position</div>
              <div class="value">${body.roleTitle}</div>
            </div>
            <div class="item">
              <div class="label">Candidate Name</div>
              <div class="value">${name}</div>
            </div>
            <div class="item">
              <div class="label">Email Address</div>
              <div class="value">${email}</div>
            </div>
            <div class="item">
              <div class="label">Phone / WhatsApp</div>
              <div class="value">${body.phone}</div>
            </div>
            <div class="item">
              <div class="label">Experience Level</div>
              <div class="value">${body.experience}</div>
            </div>
            <div class="item">
              <div class="label">Portfolio Link</div>
              <div class="value">${body.portfolio || 'None'}</div>
            </div>
            <div class="item">
              <div class="label">Resume Link</div>
              <div class="value"><a href="${body.resumeLink}" target="_blank">${body.resumeLink}</a></div>
            </div>
            <div class="item" style="border: none;">
              <div class="label">Cover Letter / Notes</div>
              <div class="value">${body.coverLetter}</div>
            </div>
            <div class="footer">
              Sent automatically from NetBots HR Gateway API
            </div>
          </div>
        </body>
        </html>
      `;
    } else {
      return NextResponse.json({ error: 'Unsupported type' }, { status: 400 });
    }

    // Deliver email to both recipient addresses
    await transporter.sendMail({
      from: '"NetBots Leads Core" <leads@netbots.io>',
      to: 'leads@netbots.io, saqlainshahbaltee@gmail.com',
      subject: emailSubject,
      html: emailHtml,
    });

    return NextResponse.json({ success: true, message: 'Message sent successfully.' }, { status: 200 });
  } catch (error) {
    console.error('[Nodemailer API] Error details:', error);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
