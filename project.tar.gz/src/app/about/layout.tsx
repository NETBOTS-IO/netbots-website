import { Metadata } from 'next';
import { JsonLd } from '@/components/structured-data/JsonLd';
import { getLocalBusinessSchema } from '@/lib/schema/schema-helpers';

export const metadata: Metadata = {
  title: 'About Net Bots | IT Company Skardu Pakistan',
  description: 'Learn about Net Bots, a premier custom software development company in Skardu, Pakistan. We specialize in AI automation, web development, and brand strategy.',
  keywords: ['IT company Skardu Pakistan', 'custom software development company', 'Net Bots Skardu'],
};

export default function AboutLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const schemaData = getLocalBusinessSchema();

  return (
    <>
      <JsonLd data={schemaData} />
      {children}
    </>
  );
}
