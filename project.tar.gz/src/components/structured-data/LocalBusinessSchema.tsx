import React from 'react';

export function LocalBusinessSchema() {
  const structuredData = {
    '@context': 'https://schema.org',
    '@type': 'LocalBusiness',
    name: 'Net Bots',
    image: 'https://netbots.io/logo.png',
    '@id': 'https://netbots.io',
    url: 'https://netbots.io',
    telephone: '',
    address: {
      '@type': 'PostalAddress',
      streetAddress: 'Hameed Ghar, District Bar Building',
      addressLocality: 'Skardu',
      addressRegion: 'Gilgit-Baltistan',
      addressCountry: 'PK',
    },
    geo: {
      '@type': 'GeoCoordinates',
      latitude: 35.2985,
      longitude: 75.6416,
    },
    openingHoursSpecification: {
      '@type': 'OpeningHoursSpecification',
      dayOfWeek: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
      opens: '09:00',
      closes: '18:00',
    },
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
    />
  );
}
