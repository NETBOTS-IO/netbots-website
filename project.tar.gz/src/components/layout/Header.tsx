'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { navigation } from '@/lib/content';
import { LeadCaptureModal } from '@/components/lead-capture/LeadCaptureModal';
import styles from './Header.module.css';

export function Header() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <>
      <header className={styles.header}>
        <div className={styles.navContainer}>
          <Link href="/" className={styles.logo} style={{ display: 'flex', alignItems: 'center' }}>
            <img src="/images/netbots-logo-original.png" alt="NetBots" style={{ height: '36px', objectFit: 'contain' }} />
          </Link>

          <nav className={`${styles.nav} ${mobileMenuOpen ? styles.navActive : ''}`}>
            {navigation.header.map((item, index) => (
              <Link
                key={index}
                href={item.href}
                className={styles.navLink}
                onClick={() => setMobileMenuOpen(false)}
              >
                {item.label}
              </Link>
            ))}
            <Link
              href="/contact"
              className={styles.mobileContact}
              onClick={() => setMobileMenuOpen(false)}
            >
              Contact
            </Link>
            <button
              onClick={() => {
                setIsModalOpen(true);
                setMobileMenuOpen(false);
              }}
              className={styles.mobileCta}
            >
              Book Your Free Audit
            </button>
          </nav>

          <div className={styles.rightSection}>
            <Link href="/contact" className={styles.contactLink}>
              Contact
            </Link>
            <button
              onClick={() => setIsModalOpen(true)}
              className={styles.ctaButton}
            >
              Book Your Free Audit
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className={styles.hamburger}
              aria-label="Toggle menu"
            >
              <span className={`${styles.bar} ${mobileMenuOpen ? styles.barOpen : ''}`} />
              <span className={`${styles.bar} ${mobileMenuOpen ? styles.barOpen : ''}`} />
              <span className={`${styles.bar} ${mobileMenuOpen ? styles.barOpen : ''}`} />
            </button>
          </div>
        </div>
      </header>

      <LeadCaptureModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </>
  );
}
